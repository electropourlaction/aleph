/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

#define STEPS 32
#define TRACKS 4
#define PATTERNS 32
#define I2CBUFSIZE 8
#define UARTBUFSIZE 4
#define DELAY 2184
#define SHIFT 520
#define PERIOD 1000
#define NOP 255


/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim6;
//TIM_HandleTypeDef htim7;

//  outputs
UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;
UART_HandleTypeDef huart7;
UART_HandleTypeDef huart8;

//  inputs
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart6;

//  debug
UART_HandleTypeDef huart3;


/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM6_Init(void);
//static void MX_TIM7_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
static void MX_UART7_Init(void);
static void MX_UART8_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USART6_UART_Init(void);

//  step
typedef struct step_t {
	uint8_t byte0;
	uint8_t byte1;
	uint8_t byte2;
	uint8_t byte3;
} step;

//  track
typedef struct track_t {
	step s[STEPS];
	int len;
	int c;
} track;

//  pattern
typedef struct pattern_t {
	track t[TRACKS];
} pattern;


/* Private function prototypes -----------------------------------------------*/
static void pattern_init(pattern p);
static void process_i2c(uint8_t cmd);
static void clock_in(void);
static void clock_return(void);
static void delay(TIM_HandleTypeDef *htim, uint16_t time);


//  i2c buffer
uint8_t ii[I2CBUFSIZE] = { 0, 0, 0, 0, 0, 0, 0, 0 };

//  uart input buffers
uint8_t input1[UARTBUFSIZE] = { 0, 0, 0, 0 };
uint8_t input2[UARTBUFSIZE] = { 0, 0, 0, 0 };

//  uart buffers
uint8_t output_ctrl[UARTBUFSIZE] = { 0, 0, 0, 0 };
uint8_t output1[UARTBUFSIZE] = { NOP, NOP, NOP, NOP };
uint8_t output2[UARTBUFSIZE] = { NOP, NOP, NOP, NOP };
uint8_t output3[UARTBUFSIZE] = { NOP, NOP, NOP, NOP };
uint8_t output4[UARTBUFSIZE] = { NOP, NOP, NOP, NOP };

//  uart output state
uint8_t state = 0;

//  mute state
uint8_t mute = 0;

//  pattern init
pattern p[PATTERNS];

//  current pattern
int cptn = 0;

//  current track
int ctrk = 0;


int main(void)
{

	int n;
	uint16_t d;

	/* MCU Configuration----------------------------------------------------------*/
	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* Configure the system clock */
	SystemClock_Config();

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_I2C1_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();
	MX_TIM6_Init();
//	MX_TIM7_Init();
	MX_UART4_Init();
	MX_UART5_Init();
	MX_UART7_Init();
	MX_UART8_Init();
	MX_USART2_UART_Init();
	MX_USART3_UART_Init();
	MX_USART6_UART_Init();

	//  initialize patterns
	for(n=0;n<PATTERNS;n++)
	{
		pattern_init(p[n]);
	}

	//  start i2c slave receive with global interrupt (nvic)
	HAL_I2C_Slave_Receive_IT(&hi2c1, ii, I2CBUFSIZE);

	//  input 1 filter | start timer 2 (200Hz) with global interrupt (nvic)
	HAL_TIM_Base_Start_IT(&htim2);

	//  input 2 filter | start timer 3 (200Hz) with global interrupt (nvic)
	HAL_TIM_Base_Start_IT(&htim3);

	//  sequencer delay | start timer 6 (19200 bit/s)
	HAL_TIM_Base_Start(&htim6);

	//  direct output delay | start timer 7 (19200 bit/s)
//	HAL_TIM_Base_Start(&htim7);

	//  input 1 | start uart receive with global interrupt (nvic)
	HAL_UART_Receive_IT(&huart2, input1, 1);

	//  input 2 | start uart receive with global interrupt (nvic)
	HAL_UART_Receive_IT(&huart6, input2, 1);


	/* Infinite loop */
	while (1)
	{
		//  sequencer mode (ready to transmit), send data to uart 4,5,7,8
		if (state == 1)
		{
			d = DELAY;

			//  transmit message 1
			if (output1[0] != NOP)
			{
				HAL_UART_Transmit(&huart4, &output1[0], 1, -1);
				d -= SHIFT;
			}
			if (output2[0] != NOP)
			{
				HAL_UART_Transmit(&huart5, &output2[0], 1, -1);
				d -= SHIFT;
			}
			if (output3[0] != NOP)
			{
				HAL_UART_Transmit(&huart7, &output3[0], 1, -1);
				d -= SHIFT;
			}
			if (output4[0] != NOP)
			{
				HAL_UART_Transmit(&huart8, &output4[0], 1, -1);
				d -= SHIFT;
			}

			//  delay
			delay(&htim6, d);

			d = DELAY;

			//  transmit message 2
			if (output1[1] != NOP)
			{
				HAL_UART_Transmit(&huart4, &output1[1], 1, -1);
				d -= SHIFT;
			}
			if (output2[1] != NOP)
			{
				HAL_UART_Transmit(&huart5, &output2[1], 1, -1);
				d -= SHIFT;
			}
			if (output3[1] != NOP)
			{
				HAL_UART_Transmit(&huart7, &output3[1], 1, -1);
				d -= SHIFT;
			}
			if (output4[1] != NOP)
			{
				HAL_UART_Transmit(&huart8, &output4[1], 1, -1);
				d -= SHIFT;
			}

			delay(&htim6, d);

			d = DELAY;

			//  transmit message 3
			if (output1[2] != NOP)
			{
				HAL_UART_Transmit(&huart4, &output1[2], 1, -1);
				d -= SHIFT;
			}
			if (output2[2] != NOP)
			{
				HAL_UART_Transmit(&huart5, &output2[2], 1, -1);
				d -= SHIFT;
			}
			if (output3[2] != NOP)
			{
				HAL_UART_Transmit(&huart7, &output3[2], 1, -1);
				d -= SHIFT;
			}
			if (output4[2] != NOP)
			{
				HAL_UART_Transmit(&huart8, &output4[2], 1, -1);
				d -= SHIFT;
			}

			delay(&htim6, d);

			//  transmit message 4
			if (output1[3] != NOP) HAL_UART_Transmit(&huart4, &output1[3], 1, -1);
			if (output2[3] != NOP) HAL_UART_Transmit(&huart5, &output2[3], 1, -1);
			if (output3[3] != NOP) HAL_UART_Transmit(&huart7, &output3[3], 1, -1);
			if (output4[3] != NOP) HAL_UART_Transmit(&huart8, &output4[3], 1, -1);

			//  end transmission
			state = 0;
		}
		//  direct mode (ready to transmit), send data to track output
		else if (state == 2)
		{
			//  output 1
			if (ctrk == 0)
			{
				//  transmit message to uart4
				HAL_UART_Transmit(&huart4, &output_ctrl[0], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[1] != NOP)
				{
					HAL_UART_Transmit(&huart4, &output_ctrl[1], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);

				HAL_UART_Transmit(&huart4, &output_ctrl[2], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[3] != NOP)
				{
					HAL_UART_Transmit(&huart4, &output_ctrl[3], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);
			}
			//  output 2
			else if (ctrk == 1)
			{
				//  transmit message to uart5
				HAL_UART_Transmit(&huart5, &output_ctrl[0], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[1] != NOP)
				{
					HAL_UART_Transmit(&huart5, &output_ctrl[1], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);

				HAL_UART_Transmit(&huart5, &output_ctrl[2], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[3] != NOP)
				{
					HAL_UART_Transmit(&huart5, &output_ctrl[3], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);
			}
			//  output 3
			else if (ctrk == 2)
			{
				//  transmit message to uart7
				HAL_UART_Transmit(&huart7, &output_ctrl[0], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[1] != NOP)
				{
					HAL_UART_Transmit(&huart7, &output_ctrl[1], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);

				HAL_UART_Transmit(&huart7, &output_ctrl[2], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[3] != NOP)
				{
					HAL_UART_Transmit(&huart7, &output_ctrl[3], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);
			}
			//  output 4
			else if (ctrk == 3)
			{
				//  transmit message to uart8
				HAL_UART_Transmit(&huart8, &output_ctrl[0], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[1] != NOP)
				{
					HAL_UART_Transmit(&huart8, &output_ctrl[1], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);

				HAL_UART_Transmit(&huart8, &output_ctrl[2], 1, -1);
				delay(&htim6, DELAY - SHIFT);

				d = DELAY;

				if (output_ctrl[3] != NOP)
				{
					HAL_UART_Transmit(&huart8, &output_ctrl[3], 1, -1);
					d -= SHIFT;
				}

				delay(&htim6, d);
			}
			else ;

			//  end transmission
			state = 0;
		}
		else HAL_Delay(1);
	}
}

/** System Clock Configuration
 */
void SystemClock_Config(void)
{

	RCC_OscInitTypeDef RCC_OscInitStruct;

	__PWR_CLK_ENABLE();

	__HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.HSICalibrationValue = 16;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
	HAL_RCC_OscConfig(&RCC_OscInitStruct);

	HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

	/* SysTick_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* I2C1 init function */
void MX_I2C1_Init(void)
{

	hi2c1.Instance = I2C1;
	hi2c1.Init.ClockSpeed = 100000;
	hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
	hi2c1.Init.OwnAddress1 = 64;
	hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLED;
	hi2c1.Init.OwnAddress2 = 0;
	hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLED;
	hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_ENABLED;
	HAL_I2C_Init(&hi2c1);

}

/* TIM2 init function */
void MX_TIM2_Init(void)
{

	TIM_ClockConfigTypeDef sClockSourceConfig;
	TIM_MasterConfigTypeDef sMasterConfig;

	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 160 - 1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_DOWN;
	htim2.Init.Period = PERIOD;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	HAL_TIM_Base_Init(&htim2);

	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig);

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig);

}

/* TIM3 init function */
void MX_TIM3_Init(void)
{

  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 160 - 1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_DOWN;
  htim3.Init.Period = PERIOD;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  HAL_TIM_Base_Init(&htim3);

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig);

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig);

}

/* TIM6 init function */
void MX_TIM6_Init(void)
{

	TIM_MasterConfigTypeDef sMasterConfig;

	//  set period
	uint32_t Period = 1000000 / 100;

	htim6.Instance = TIM6;
	htim6.Init.Prescaler = (SystemCoreClock / 1000000) - 1;
	htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim6.Init.Period = Period - 1;
	HAL_TIM_Base_Init(&htim6);

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig);

}

/* UART4 init function */
void MX_UART4_Init(void)
{

	huart4.Instance = UART4;
	huart4.Init.BaudRate = 19200;
	huart4.Init.WordLength = UART_WORDLENGTH_8B;
	huart4.Init.StopBits = UART_STOPBITS_1;
	huart4.Init.Parity = UART_PARITY_NONE;
	huart4.Init.Mode = UART_MODE_TX;
	huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart4.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&huart4);

}

/* UART5 init function */
void MX_UART5_Init(void)
{

	huart5.Instance = UART5;
	huart5.Init.BaudRate = 19200;
	huart5.Init.WordLength = UART_WORDLENGTH_8B;
	huart5.Init.StopBits = UART_STOPBITS_1;
	huart5.Init.Parity = UART_PARITY_NONE;
	huart5.Init.Mode = UART_MODE_TX;
	huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart5.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&huart5);

}

/* UART7 init function */
void MX_UART7_Init(void)
{

	huart7.Instance = UART7;
	huart7.Init.BaudRate = 19200;
	huart7.Init.WordLength = UART_WORDLENGTH_8B;
	huart7.Init.StopBits = UART_STOPBITS_1;
	huart7.Init.Parity = UART_PARITY_NONE;
	huart7.Init.Mode = UART_MODE_TX;
	huart7.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart7.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&huart7);

}

/* UART8 init function */
void MX_UART8_Init(void)
{

	huart8.Instance = UART8;
	huart8.Init.BaudRate = 19200;
	huart8.Init.WordLength = UART_WORDLENGTH_8B;
	huart8.Init.StopBits = UART_STOPBITS_1;
	huart8.Init.Parity = UART_PARITY_NONE;
	huart8.Init.Mode = UART_MODE_TX;
	huart8.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart8.Init.OverSampling = UART_OVERSAMPLING_16;
	HAL_UART_Init(&huart8);

}

/* USART2 init function */
void MX_USART2_UART_Init(void)
{

  huart2.Instance = USART2;
  huart2.Init.BaudRate = 19200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart2);

}

/* USART3 init function */
void MX_USART3_UART_Init(void)
{

  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart3);

}

/* USART6 init function */
void MX_USART6_UART_Init(void)
{

  huart6.Instance = USART6;
  huart6.Init.BaudRate = 19200;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart6);

}

void MX_GPIO_Init(void)
{

	GPIO_InitTypeDef GPIO_InitStruct;

	/* GPIO Ports Clock Enable */
	__GPIOC_CLK_ENABLE();
	__GPIOF_CLK_ENABLE();
	__GPIOH_CLK_ENABLE();
	__GPIOA_CLK_ENABLE();
	__GPIOB_CLK_ENABLE();
	__GPIOD_CLK_ENABLE();
	__GPIOG_CLK_ENABLE();
	__GPIOE_CLK_ENABLE();

	/*Configure GPIO pin : User_Blue_Button_Pin */
	GPIO_InitStruct.Pin = User_Blue_Button_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(User_Blue_Button_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : RMII_MDC_Pin RMII_RXD0_Pin RMII_RXD1_Pin */
	GPIO_InitStruct.Pin = RMII_MDC_Pin|RMII_RXD0_Pin|RMII_RXD1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pins : RMII_REF_CK_Pin RMII_MDIO_Pin RMII_CRS_DV_Pin */
	GPIO_InitStruct.Pin = RMII_REF_CK_Pin|RMII_MDIO_Pin|RMII_CRS_DV_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : RMII_TXD1_Pin */
	GPIO_InitStruct.Pin = RMII_TXD1_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
	HAL_GPIO_Init(RMII_TXD1_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : LD3_Pin LD2_Pin */
	GPIO_InitStruct.Pin = LD3_Pin|LD2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pin : USB_PowerSwitchOn_Pin */
	GPIO_InitStruct.Pin = USB_PowerSwitchOn_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
	HAL_GPIO_Init(USB_PowerSwitchOn_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pin : USB_OverCurrent_Pin */
	GPIO_InitStruct.Pin = USB_OverCurrent_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(USB_OverCurrent_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : USB_SOF_Pin USB_ID_Pin USB_DM_Pin USB_DP_Pin */
	GPIO_InitStruct.Pin = USB_SOF_Pin|USB_ID_Pin|USB_DM_Pin|USB_DP_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF10_OTG_FS;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pin : USB_VBUS_Pin */
	GPIO_InitStruct.Pin = USB_VBUS_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(USB_VBUS_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : RMII_TX_EN_Pin RMII_TXD0_Pin */
	GPIO_InitStruct.Pin = RMII_TX_EN_Pin|RMII_TXD0_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
	GPIO_InitStruct.Alternate = GPIO_AF11_ETH;
	HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

}

//init
void pattern_init(pattern p)
{
	int i, n;

	for(n=0;n<TRACKS;n++)
	{
		for(i=0;i<STEPS;i++)
		{
			p.t[n].s[i].byte0 = NOP;
			p.t[n].s[i].byte1 = NOP;
			p.t[n].s[i].byte2 = NOP;
			p.t[n].s[i].byte3 = NOP;
		}
		p.t[n].len = STEPS;
		p.t[n].c = 0;
	}
}

//callback
void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
	//  wait for transfer
//	while (hi2c1.XferCount) ;

	//  wait for RX
	while (hi2c->State == HAL_I2C_STATE_BUSY_RX);

	//  process message
	process_i2c(ii[0]);

	//  reset buffer
	hi2c1.XferCount = I2CBUFSIZE;
	hi2c1.pBuffPtr = ii;

	//  SDA low
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, RESET);

	//  set ACK
	hi2c1.Instance->CR1 |= I2C_CR1_ACK;

	//  set ITEVTEN
	hi2c1.Instance->CR2 |= I2C_CR2_ITEVTEN;

	//  set ITBUFEN
	hi2c1.Instance->CR2 |= I2C_CR2_ITBUFEN;

	//  SDA high
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, SET);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart == &huart2)
	{
		while (huart->Instance->SR & USART_SR_RXNE)
		{
			*huart->pRxBuffPtr++ = (uint8_t)(huart->Instance->DR & (uint8_t)0x00FF);
			--huart->RxXferCount;
	    }

		//  reset uart buffer
		huart->RxXferCount = 1;
		huart->pRxBuffPtr = input1;

		//  set i2c in ready state
	    hi2c1.State = HAL_I2C_STATE_READY;

	    //  filter incoming messages
	    if (!htim2.Instance->CNT)
	    {
	    	//  reset timer
	    	htim2.Instance->CNT = PERIOD / 2;
	    	HAL_TIM_Base_Start(&htim2);

	        //  transmit to address 0x50 (with address shift!)
	    	HAL_I2C_Master_Transmit(&hi2c1, 160, input1, 1, -1);
	    }
	}
	else if (huart == &huart6)
	{
		while (huart->Instance->SR & USART_SR_RXNE)
		{
			*huart->pRxBuffPtr++ = (uint8_t)(huart->Instance->DR & (uint8_t)0x00FF);
			--huart->RxXferCount;
	    }

		input2[0] += 64;

		//  reset uart buffer
		huart->RxXferCount = 1;
		huart->pRxBuffPtr = input2;

		//  set i2c in ready state
	    hi2c1.State = HAL_I2C_STATE_READY;

	    //  filter incoming messages
	    if (!htim3.Instance->CNT)
	    {
	    	//  reset timer
	    	htim3.Instance->CNT = PERIOD / 2;
	    	HAL_TIM_Base_Start(&htim3);

	        //  transmit to address 0x50 (with address shift!)
	    	HAL_I2C_Master_Transmit(&hi2c1, 160, input2, 1, -1);
	    }
	}
}

//utility
void process_i2c(uint8_t cmd)
{
	uint8_t np, nt, ns, nl;

	switch (cmd) {
			//  clock
		case 0:
			clock_in();
			break;

			//  return to step 1
		case 1:
			clock_return();
			break;

			//  edit pattern | pattern, track, step, byte0, byte1, byte2, byte3
		case 2:
			np = cptn = ii[1];
			nt = ii[2];
			ns = ii[3];
			p[np].t[nt].s[ns].byte0 = ii[4];
			p[np].t[nt].s[ns].byte1 = ii[5];
			p[np].t[nt].s[ns].byte2 = ii[6];
			p[np].t[nt].s[ns].byte3 = ii[7];
			break;

			//  pattern change | pattern
		case 3:
			cptn = ii[1];
			break;

			//  track length | pattern, track, length
		case 4:
			cptn = ii[1];
			nt = ii[2];
			nl = ii[3];
			p[cptn].t[nt].len = nl;
			break;

			//  sequencer mute
		case 5:
			mute = 1;
			break;

			//  sequencer unmute
		case 6:
			mute = 0;
			break;

			//  direct speed | output (track), byte0, byte1, byte2
		case 7:
			nt = ctrk = ii[1];
			output_ctrl[0] = ii[2];
			output_ctrl[1] = ii[3];
			output_ctrl[2] = ii[4];
			output_ctrl[3] = NOP;
			//  start transmission, if sequencer is muted
			if (mute) state = 2;
			break;

			//  direct pitch | output (track), byte0, byte1, byte2, byte3
		case 8:
			nt = ctrk = ii[1];
			output_ctrl[0] = ii[2];
			output_ctrl[1] = ii[3];
			output_ctrl[2] = ii[4];
			output_ctrl[3] = ii[5];
			if (mute) state = 2;
			break;

			//  direct command | output (track), byte0
		case 9:
			nt = ctrk = ii[1];
			output_ctrl[0] = ii[2];
			output_ctrl[1] = NOP;
			output_ctrl[2] = ii[2];
			output_ctrl[3] = NOP;
			if (mute) state = 2;
			break;

			//  stm32 software reset | command
		case 10:
			HAL_NVIC_SystemReset();
			break;


		default:
			break;
	}
}

void clock_in(void)
{
	uint8_t np = cptn;
	uint8_t n;
	uint8_t c[4];

	for (n=0; n<TRACKS; n++)
	{
		c[n] = p[np].t[n].c += 1;
		if (c[n] > p[np].t[n].len - 1) c[n] = p[np].t[n].c = 0;
	}

	//  load uart buffers
	output1[0] = p[np].t[0].s[c[0]].byte0;
	output1[1] = p[np].t[0].s[c[0]].byte1;
	output1[2] = p[np].t[0].s[c[0]].byte2;
	output1[3] = p[np].t[0].s[c[0]].byte3;

	output2[0] = p[np].t[1].s[c[1]].byte0;
	output2[1] = p[np].t[1].s[c[1]].byte1;
	output2[2] = p[np].t[1].s[c[1]].byte2;
	output2[3] = p[np].t[1].s[c[1]].byte3;

	output3[0] = p[np].t[2].s[c[2]].byte0;
	output3[1] = p[np].t[2].s[c[2]].byte1;
	output3[2] = p[np].t[2].s[c[2]].byte2;
	output3[3] = p[np].t[2].s[c[2]].byte3;

	output4[0] = p[np].t[3].s[c[3]].byte0;
	output4[1] = p[np].t[3].s[c[3]].byte1;
	output4[2] = p[np].t[3].s[c[3]].byte2;
	output4[3] = p[np].t[3].s[c[3]].byte3;

	//  start transmission, if sequencer is not muted
	if (!mute) state = 1;
}

static void clock_return(void)
{
	uint8_t n;

	for(n=0; n<TRACKS; n++)
	{
		p[cptn].t[n].c = p[cptn].t[n].len - 1;
	}
}

void delay(TIM_HandleTypeDef *htim, uint16_t time)
{
	uint32_t start, current;

	start = htim->Instance->CNT = 0;

	do
	{
		current = htim->Instance->CNT;
	}
	while ((current - start) < time);
}


#ifdef USE_FULL_ASSERT

void assert_failed(uint8_t* file, uint32_t line)
{
	;
}

#endif
